﻿using System;
using Xunit;

namespace AnonymousId.Tests
{
    public class AnonymousIdDataTests
    {
        [Fact]
        public void Constructor_ValidArguments_Succeeds()
        {
            var anonymousId = Guid.NewGuid().ToString();
            var expireDate = DateTime.UtcNow.AddDays(5);

            var anonymousIdData = new AnonymousIdData(anonymousId, expireDate);

            Assert.Equal(anonymousIdData.AnonymousId, anonymousId);
            Assert.Equal(anonymousIdData.ExpireDate, expireDate);
        }

        [Fact]
        public void Constructor_ExpireDateExpired_AnonymousIdShouldBeNull()
        {
            var anonymousId = Guid.NewGuid().ToString();
            var expireDate = DateTime.UtcNow.AddDays(-5);

            var anonymousIdData = new AnonymousIdData(anonymousId, expireDate);
            Assert.Null(anonymousIdData.AnonymousId);
        }
    }
}
