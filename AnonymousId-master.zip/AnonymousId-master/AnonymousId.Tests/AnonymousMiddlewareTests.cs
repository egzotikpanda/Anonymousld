﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Http.Internal;
using Moq;
using System.Security.Claims;
using System.Threading.Tasks;
using Xunit;

namespace AnonymousId.Tests
{
    public class AnonymousMiddlewareTests
    {
        [Fact]
        public async Task HandleRequest_Valid_CreatesCookie()
        {
            var cookieOptions = new AnonymousIdCookieOptionsBuilder().Build();

            var requestMock = new Mock<HttpRequest>();
            requestMock.Setup(x => x.Cookies).Returns(new RequestCookieCollection());

            var userMock = new Mock<ClaimsPrincipal>();
            userMock.Setup(x => x.Identity).Returns(new ClaimsIdentity());

            var contextMock = new Mock<HttpContext>();
            contextMock.Setup(x => x.Features).Returns(new FeatureCollection());
            contextMock.Setup(x => x.Request).Returns(requestMock.Object);
            contextMock.Setup(x => x.Response).Returns(new DefaultHttpResponse(new DefaultHttpContext()));
            contextMock.Setup(x => x.User).Returns(userMock.Object);

            var anonymousIdMiddleware = new AnonymousIdMiddleware((innerHttpContext)=>Task.FromResult(0), cookieOptions);
            await anonymousIdMiddleware.Invoke(contextMock.Object);

            Assert.NotNull(contextMock.Object.Features.Get<IAnonymousIdFeature>());
            Assert.False(string.IsNullOrWhiteSpace(contextMock.Object.Features.Get<IAnonymousIdFeature>().AnonymousId));
        }
    }
}
