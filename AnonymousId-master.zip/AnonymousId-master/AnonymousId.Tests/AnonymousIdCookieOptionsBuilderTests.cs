﻿using Xunit;

namespace AnonymousId.Tests
{
    public class AnonymousIdCookieOptionsBuilderTests
    {
        [Fact]
        public void Build_DefaultValues_Succeeds()
        {
            var options = new AnonymousIdCookieOptionsBuilder().Build();

            Assert.Equal(".ASPXANONYMOUS", options.Name);
            Assert.Equal("/", options.Path);
            Assert.Equal(100000, options.Timeout);
            Assert.Null(options.Domain);
            Assert.False(options.Secure);
        }

        [Fact]
        public void Build_CustomValues_Succeeds()
        {
            var options = new AnonymousIdCookieOptionsBuilder()
                .SetCustomCookieName(".CUSTOMCOOKIENAME")
                .SetCustomCookiePath("/mycustompath")
                .SetCustomCookieDomain("www.iakademi.com")
                .SetCustomCookieTimeout(1000)
                .SetCustomCookieRequireSsl(true)
                .Build();

            Assert.Equal(".CUSTOMCOOKIENAME", options.Name);
            Assert.Equal("/mycustompath", options.Path);
            Assert.Equal("www.iakademi.com", options.Domain);
            Assert.Equal(1000, options.Timeout);
            Assert.True(options.Secure);
        }

        [Theory]
        [InlineData(-100)]
        [InlineData(-1)]
        [InlineData(-0)]
        public void SetCustomCookieTimeout_WhenLessThanMinTimeout_ShouldBeEqualToMinTimeout(int timeout)
        {
            var options = new AnonymousIdCookieOptionsBuilder()
                .SetCustomCookieTimeout(timeout) 
                .Build();

            Assert.Equal(1, options.Timeout);
        }

        [Theory]
        [InlineData(123456789)]
        public void SetCustomCookieTimeout_WhenGreaterThanMaxTimeout_ShouldBeEqualToMaxTimeout(int timeout)
        {
            var options = new AnonymousIdCookieOptionsBuilder()
                .SetCustomCookieTimeout(timeout)
                .Build();

            Assert.Equal(60 * 60 * 24 * 365 * 2, options.Timeout);
        }
    }
}
