﻿using System;
using Xunit;

namespace AnonymousId.Tests
{
    public class AnonymousIdEncoderTests
    {
        [Fact]
        public void EncodeAndDecode_ValidArguments_Succeeds()
        {
            var anonymousIdData = new AnonymousIdData(Guid.NewGuid().ToString(), DateTime.UtcNow.AddDays(5));
            var encodedValue = AnonymousIdEncoder.Encode(anonymousIdData);
            var decodedValue = AnonymousIdEncoder.Decode(encodedValue);

            Assert.Equal(anonymousIdData.AnonymousId, decodedValue.AnonymousId);
            Assert.Equal(anonymousIdData.ExpireDate, decodedValue.ExpireDate);
        }
    }
}
