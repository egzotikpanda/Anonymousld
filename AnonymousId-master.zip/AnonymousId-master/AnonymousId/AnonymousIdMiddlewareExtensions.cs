﻿using Microsoft.AspNetCore.Builder;

namespace AnonymousId
{
    public static class AnonymousIdMiddlewareExtensions
    {
        public static IApplicationBuilder UseAnonymousId(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<AnonymousIdMiddleware>(new AnonymousIdCookieOptionsBuilder().Build());
        }
    }
}
