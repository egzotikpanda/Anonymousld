﻿using Microsoft.AspNetCore.Http;

namespace AnonymousId
{
    public class AnonymousIdCookieOptions : CookieOptions
    {
        public string Name { get; set; }
        public bool SlidingExpiration { get; set; }
        public int Timeout { get; set; }
    }
}
