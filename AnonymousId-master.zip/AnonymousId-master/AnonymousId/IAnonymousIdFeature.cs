﻿namespace AnonymousId
{
    public interface IAnonymousIdFeature
    {
        string AnonymousId { get; set; }
    }
}
