﻿using System;

namespace AnonymousId
{
    internal class AnonymousIdData
    {
        internal string AnonymousId;
        internal DateTime ExpireDate;

        internal AnonymousIdData(string id, DateTime expireDate)
        {
            AnonymousId = (expireDate > DateTime.UtcNow) ? id : null;
            ExpireDate = expireDate;
        }
    }
}
