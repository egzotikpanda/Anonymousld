﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Text;

namespace AnonymousId
{
    internal static class AnonymousIdEncoder
    {
        internal static string Encode(AnonymousIdData data)
        {
            if (data == null || string.IsNullOrWhiteSpace(data.AnonymousId))
                return null;

            var bufferId = Encoding.UTF8.GetBytes(data.AnonymousId);
            var bufferIdLength = BitConverter.GetBytes(bufferId.Length);
            var bufferDate = BitConverter.GetBytes(data.ExpireDate.ToFileTimeUtc());
            var buffer = new byte[12 + bufferId.Length];

            Buffer.BlockCopy(bufferDate, 0, buffer, 0, 8);
            Buffer.BlockCopy(bufferIdLength, 0, buffer, 8, 4);
            Buffer.BlockCopy(bufferId, 0, buffer, 12, bufferId.Length);

            return Base64UrlEncoder.Encode(buffer);
        }

        internal static AnonymousIdData Decode(string data)
        {
            if (data == null || data.Length < 1)
                return null;

            try
            {
                var blob = Base64UrlEncoder.DecodeBytes(data);

                if (blob == null || blob.Length < 13)
                    return null;

                var expireDate = DateTime.FromFileTimeUtc(BitConverter.ToInt64(blob, 0));

                if (expireDate < DateTime.UtcNow)
                    return null;

                int length = BitConverter.ToInt32(blob, 8);

                if (length < 0 || length > blob.Length - 12)
                    return null;

                string id = Encoding.UTF8.GetString(blob, 12, length);

                return new AnonymousIdData(id, expireDate);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
