﻿using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace AnonymousId
{
    public class AnonymousIdMiddleware
    {
        private readonly RequestDelegate _nextDelegate;
        private readonly AnonymousIdCookieOptions _anonymousIdCookieOptions;

        public AnonymousIdMiddleware(RequestDelegate nextDelegate, AnonymousIdCookieOptions anonymousIdCookieOptions)
        {
            _nextDelegate = nextDelegate;
            _anonymousIdCookieOptions = anonymousIdCookieOptions;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            HandleRequest(httpContext);
            await _nextDelegate.Invoke(httpContext);
        }

        private void HandleRequest(HttpContext httpContext)
        {
            string encodedValue;
            bool isAuthenticated = httpContext.User.Identity.IsAuthenticated;
            DateTime now = DateTime.Now;

            //Handle secure cookies over an unsecured connection
            if (_anonymousIdCookieOptions.Secure && !httpContext.Request.IsHttps)
            {
                encodedValue = httpContext.Request.Cookies[_anonymousIdCookieOptions.Name];
                if (!string.IsNullOrWhiteSpace(encodedValue))
                    httpContext.Response.Cookies.Delete(_anonymousIdCookieOptions.Name);

                //Adds the feature to request collection
                httpContext.Features.Set<IAnonymousIdFeature>(new AnonymousIdFeature());

                return;
            }

            //Get the value and anonymousId data from the cookie, if avaiable

            encodedValue = httpContext.Request.Cookies[_anonymousIdCookieOptions.Name];
            var decodedValue = AnonymousIdEncoder.Decode(encodedValue);

            string anonymousId = null;

            if (decodedValue != null && !string.IsNullOrWhiteSpace(decodedValue.AnonymousId))
            {
                //Copy the existing value in Request header
                anonymousId = decodedValue.AnonymousId;

                //Add the feature in request collection
                httpContext.Features.Set<IAnonymousIdFeature>(new AnonymousIdFeature
                {
                    AnonymousId = anonymousId
                });
            }

            //User is already authenticated
            if (isAuthenticated)
                return;

            if (_anonymousIdCookieOptions.Secure && !httpContext.Request.IsHttps)
                return;

            if (string.IsNullOrWhiteSpace(anonymousId))
            {
                anonymousId = Guid.NewGuid().ToString();

                //Add the feature in request collection
                httpContext.Features.Set<IAnonymousIdFeature>(new AnonymousIdFeature
                {
                    AnonymousId = anonymousId
                });
            }
            else
            {
                //Sliding request is not required for this request
                if (!_anonymousIdCookieOptions.SlidingExpiration || (decodedValue != null && decodedValue.ExpireDate > now && (decodedValue.ExpireDate - now).TotalSeconds > (_anonymousIdCookieOptions.Timeout * 60) / 2))
                    return;
            }

            //Reset cookie expiration time
            _anonymousIdCookieOptions.Expires = DateTime.UtcNow.AddSeconds(_anonymousIdCookieOptions.Timeout);

            //Append the new cookie
            var data = new AnonymousIdData(anonymousId, _anonymousIdCookieOptions.Expires.Value.DateTime);
            encodedValue = AnonymousIdEncoder.Encode(data);
            httpContext.Response.Cookies.Append(_anonymousIdCookieOptions.Name, encodedValue, _anonymousIdCookieOptions);
        }
    }
}
