﻿namespace AnonymousId
{
    public class AnonymousIdFeature : IAnonymousIdFeature
    {
        public string AnonymousId { get; set; }
    }
}
