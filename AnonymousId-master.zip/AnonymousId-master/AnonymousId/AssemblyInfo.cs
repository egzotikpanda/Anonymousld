﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("AnonymousId.Tests")]